<!doctype html>
<html lang="en-US">
<head>
	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<meta name='robots' content='noindex, follow' />
<!-- Jetpack Site Verification Tags -->
<meta name="google-site-verification" content="YX6tSGKaTXvTxyTPwg0ufKpYPgmVXpGnr2hVaICII50" />
<meta name="msvalidate.01" content="2633057DB01A917911F59FDC6320756B" />

	<!-- This site is optimized with the Yoast SEO plugin v19.6 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Data Science | Machine Learning | Python | C++ | Coding | Programming | JavaScript</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Data Science | Machine Learning | Python | C++ | Coding | Programming | JavaScript" />
	<meta property="og:site_name" content="Data Science | Machine Learning | Python | C++ | Coding | Programming | JavaScript" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://thecleverprogrammer.com/#website","url":"https://thecleverprogrammer.com/","name":"Data Science | Machine Learning | Python | C++ | Coding | Programming | JavaScript","description":"Learn Python, C++, Coding, Machine Learning, Data Science, Artificial Intelligence and JavaScript.","publisher":{"@id":"https://thecleverprogrammer.com/#/schema/person/846474f6a64a2bcf3beec256fb22260b"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://thecleverprogrammer.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":["Person","Organization"],"@id":"https://thecleverprogrammer.com/#/schema/person/846474f6a64a2bcf3beec256fb22260b","name":"Aman Kharwal","image":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://thecleverprogrammer.com/#/schema/person/image/","url":"https://i1.wp.com/thecleverprogrammer.com/wp-content/uploads/2021/04/aman-removebg.png?fit=658%2C545&ssl=1","contentUrl":"https://i1.wp.com/thecleverprogrammer.com/wp-content/uploads/2021/04/aman-removebg.png?fit=658%2C545&ssl=1","width":658,"height":545,"caption":"Aman Kharwal"},"logo":{"@id":"https://thecleverprogrammer.com/#/schema/person/image/"},"description":"Coder with the ♥️ of a Writer || Data Scientist | Solopreneur | Founder","sameAs":["http://Thecleverprogrammer.com","https://www.facebook.com/thecleverprogrammer","https://www.instagram.com/the.clever.programmer/","https://twitter.com/amankk_9"]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//secure.gravatar.com' />
<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel='dns-prefetch' href='//widgets.wp.com' />
<link rel='dns-prefetch' href='//jetpack.wordpress.com' />
<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//public-api.wordpress.com' />
<link rel='dns-prefetch' href='//0.gravatar.com' />
<link rel='dns-prefetch' href='//1.gravatar.com' />
<link rel='dns-prefetch' href='//2.gravatar.com' />
<link rel='dns-prefetch' href='//i0.wp.com' />
<link rel='dns-prefetch' href='//c0.wp.com' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel='stylesheet' id='all-css-a22f7e7286477fc3db4d192efbce1b2f' href='https://thecleverprogrammer.com/_static/??-eJyVU0tywjAMvVCNyaadLjrdMNMD9AT+aIJB/jSSSXP7OjFhKDQUZrKIPu9JepL7JEwMDIFlwty6QLLNxdTQtVJnh1ZqjGYv0OlOdYMkHhBWhuipv4aiGmJm0XbO/k50wWC2QHJH0oN1ChD8iDw3UoFDJxBaZYaVd+FfdImd2+eYy9ZMnOYgaR1xbU7MPtFconwWM7BPJnraygMEGzupMkevmJ2RDN9c64ve2RZYTLSlFhVY9Yw5Sy319iCUHgXzcGSQKWss1BPDdVjU8BLh5eZK4ymGkkG313bS5iT0BlIZF4JxxfiIG2XtID/rdJUbFQMtjrYDTsrspY82T4qoLmYClNS7VHasc7DL/SyijwExO+4lYIdgRasQoZzwDeteQnR7WBCVt+UWqb4aGt+LGm+lDiy9Khf6x5XeBCXVgmDHpdajUD2qxbF86WEsOQtadQ/jvrIGHG69xVnN8cqP/2Pqu39rnp+b9bp5fWl+AK9gwmU=' type='text/css' media='all' />
<style id='wp-block-library-inline-css'>
.has-text-align-justify{text-align:justify;}
</style>
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--palette-color-1: var(--paletteColor1, #3eaf7c);--wp--preset--color--palette-color-2: var(--paletteColor2, #33a370);--wp--preset--color--palette-color-3: var(--paletteColor3, rgba(44, 62, 80, 0.9));--wp--preset--color--palette-color-4: var(--paletteColor4, rgba(44, 62, 80, 1));--wp--preset--color--palette-color-5: var(--paletteColor5, #ffffff);--wp--preset--color--palette-color-6: var(--paletteColor6, #f2f5f7);--wp--preset--color--palette-color-7: var(--paletteColor7, #FAFBFC);--wp--preset--color--palette-color-8: var(--paletteColor8, #ffffff);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--gradient--juicy-peach: linear-gradient(to right, #ffecd2 0%, #fcb69f 100%);--wp--preset--gradient--young-passion: linear-gradient(to right, #ff8177 0%, #ff867a 0%, #ff8c7f 21%, #f99185 52%, #cf556c 78%, #b12a5b 100%);--wp--preset--gradient--true-sunset: linear-gradient(to right, #fa709a 0%, #fee140 100%);--wp--preset--gradient--morpheus-den: linear-gradient(to top, #30cfd0 0%, #330867 100%);--wp--preset--gradient--plum-plate: linear-gradient(135deg, #667eea 0%, #764ba2 100%);--wp--preset--gradient--aqua-splash: linear-gradient(15deg, #13547a 0%, #80d0c7 100%);--wp--preset--gradient--love-kiss: linear-gradient(to top, #ff0844 0%, #ffb199 100%);--wp--preset--gradient--new-retrowave: linear-gradient(to top, #3b41c5 0%, #a981bb 49%, #ffc8a9 100%);--wp--preset--gradient--plum-bath: linear-gradient(to top, #cc208e 0%, #6713d2 100%);--wp--preset--gradient--high-flight: linear-gradient(to right, #0acffe 0%, #495aff 100%);--wp--preset--gradient--teen-party: linear-gradient(-225deg, #FF057C 0%, #8D0B93 50%, #321575 100%);--wp--preset--gradient--fabled-sunset: linear-gradient(-225deg, #231557 0%, #44107A 29%, #FF1361 67%, #FFF800 100%);--wp--preset--gradient--arielle-smile: radial-gradient(circle 248px at center, #16d9e3 0%, #30c7ec 47%, #46aef7 100%);--wp--preset--gradient--itmeo-branding: linear-gradient(180deg, #2af598 0%, #009efd 100%);--wp--preset--gradient--deep-blue: linear-gradient(to right, #6a11cb 0%, #2575fc 100%);--wp--preset--gradient--strong-bliss: linear-gradient(to right, #f78ca0 0%, #f9748f 19%, #fd868c 60%, #fe9a8b 100%);--wp--preset--gradient--sweet-period: linear-gradient(to top, #3f51b1 0%, #5a55ae 13%, #7b5fac 25%, #8f6aae 38%, #a86aa4 50%, #cc6b8e 62%, #f18271 75%, #f3a469 87%, #f7c978 100%);--wp--preset--gradient--purple-division: linear-gradient(to top, #7028e4 0%, #e5b2ca 100%);--wp--preset--gradient--cold-evening: linear-gradient(to top, #0c3483 0%, #a2b6df 100%, #6b8cce 100%, #a2b6df 100%);--wp--preset--gradient--mountain-rock: linear-gradient(to right, #868f96 0%, #596164 100%);--wp--preset--gradient--desert-hump: linear-gradient(to top, #c79081 0%, #dfa579 100%);--wp--preset--gradient--ethernal-constance: linear-gradient(to top, #09203f 0%, #537895 100%);--wp--preset--gradient--happy-memories: linear-gradient(-60deg, #ff5858 0%, #f09819 100%);--wp--preset--gradient--grown-early: linear-gradient(to top, #0ba360 0%, #3cba92 100%);--wp--preset--gradient--morning-salad: linear-gradient(-225deg, #B7F8DB 0%, #50A7C2 100%);--wp--preset--gradient--night-call: linear-gradient(-225deg, #AC32E4 0%, #7918F2 48%, #4801FF 100%);--wp--preset--gradient--mind-crawl: linear-gradient(-225deg, #473B7B 0%, #3584A7 51%, #30D2BE 100%);--wp--preset--gradient--angel-care: linear-gradient(-225deg, #FFE29F 0%, #FFA99F 48%, #FF719A 100%);--wp--preset--gradient--juicy-cake: linear-gradient(to top, #e14fad 0%, #f9d423 100%);--wp--preset--gradient--rich-metal: linear-gradient(to right, #d7d2cc 0%, #304352 100%);--wp--preset--gradient--mole-hall: linear-gradient(-20deg, #616161 0%, #9bc5c3 100%);--wp--preset--gradient--cloudy-knoxville: linear-gradient(120deg, #fdfbfb 0%, #ebedee 100%);--wp--preset--gradient--soft-grass: linear-gradient(to top, #c1dfc4 0%, #deecdd 100%);--wp--preset--gradient--saint-petersburg: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);--wp--preset--gradient--everlasting-sky: linear-gradient(135deg, #fdfcfb 0%, #e2d1c3 100%);--wp--preset--gradient--kind-steel: linear-gradient(-20deg, #e9defa 0%, #fbfcdb 100%);--wp--preset--gradient--over-sun: linear-gradient(60deg, #abecd6 0%, #fbed96 100%);--wp--preset--gradient--premium-white: linear-gradient(to top, #d5d4d0 0%, #d5d4d0 1%, #eeeeec 31%, #efeeec 75%, #e9e9e7 100%);--wp--preset--gradient--clean-mirror: linear-gradient(45deg, #93a5cf 0%, #e4efe9 100%);--wp--preset--gradient--wild-apple: linear-gradient(to top, #d299c2 0%, #fef9d7 100%);--wp--preset--gradient--snow-again: linear-gradient(to top, #e6e9f0 0%, #eef1f5 100%);--wp--preset--gradient--confident-cloud: linear-gradient(to top, #dad4ec 0%, #dad4ec 1%, #f3e7e9 100%);--wp--preset--gradient--glass-water: linear-gradient(to top, #dfe9f3 0%, white 100%);--wp--preset--gradient--perfect-white: linear-gradient(-225deg, #E3FDF5 0%, #FFE6FA 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--10: 0.3rem;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--spacing--90: 7.59rem;--wp--preset--spacing--100: 11.39rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-audio{margin: 0 0 1em 0;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-table > table{margin: 0 0 1em 0;}
.wp-block-video{margin: 0 0 1em 0;}
.wp-block-embed{margin: 0 0 1em 0;}
</style>
<link rel='stylesheet' id='fontawesomepublic-css'  href='https://thecleverprogrammer.com/wp-content/plugins/wdv-about-me-widget/public/../includes/fonts/css/all.min.css?ver=5.9.0' media='all' />
<link rel='stylesheet' id='fontawesomepublicv4-css'  href='https://thecleverprogrammer.com/wp-content/plugins/wdv-about-me-widget/public/../includes/fonts/css/v4-shims.min.css?ver=5.9.0' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://thecleverprogrammer.com/wp-includes/css/dashicons.min.css?ver=6.0.1' media='all' />
<style id='jetpack-global-styles-frontend-style-inline-css'>
:root { --font-headings: unset; --font-base: unset; --font-headings-default: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif; --font-base-default: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;}
</style>
<script id='qubely_local_script-js-extra'>
var qubely_urls = {"plugin":"https:\/\/thecleverprogrammer.com\/wp-content\/plugins\/qubely\/","ajax":"https:\/\/thecleverprogrammer.com\/wp-admin\/admin-ajax.php","nonce":"f80eb69d56","actual_url":"thecleverprogrammer.com"};
</script>
<script id='qubely_container_width-js-extra'>
var qubely_container_width = {"sm":"480","md":"690","lg":"1000","xl":"1200"};
</script>
<script src='https://thecleverprogrammer.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript'  src='https://thecleverprogrammer.com/_static/??-eJx9jtsKwjAQRH/I7XqBEh/ET5FclrBxk8Y2Mfj3pthHFQaG4cBwWgZOVqqjBUPPo9L82goi+1kXGiKnISy7lsFOqVAqmKV6Tgs29wRtplogEjR2njqrRtiub18ofOiPu0Ala3vHW3dCU1kcFhZy4LXIKvZnbZbXeDmMJ6XO43Gv3trbUo0='></script>

<!-- Google Analytics snippet added by Site Kit -->
<script src='https://www.googletagmanager.com/gtag/js?id=UA-161424785-3' id='google_gtagjs-js' async></script>
<script id='google_gtagjs-js-after'>
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag('set', 'linker', {"domains":["thecleverprogrammer.com"]} );
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "UA-161424785-3", {"anonymize_ip":true});
</script>

<!-- End Google Analytics snippet added by Site Kit -->
<link rel="https://api.w.org/" href="https://thecleverprogrammer.com/wp-json/" /><meta name="generator" content="Site Kit by Google 1.81.0" /><script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6306647371633064"
     crossorigin="anonymous"></script>                <!-- auto ad code generated with Simple Google Adsense plugin v1.0.9 -->
                <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <script>
                (adsbygoogle = window.adsbygoogle || []).push({
                     google_ad_client: "ca-pub-6306647371633064",
                     enable_page_level_ads: true
                });
                </script>      
                <!-- / Simple Google Adsense plugin --><style>img#wpstats{display:none}</style>
	<noscript><link rel='stylesheet' href='https://thecleverprogrammer.com/wp-content/themes/blocksy/static/bundle/no-scripts.min.css' type='text/css' /></noscript>
<style id="ct-main-styles-inline-css">[data-header*="type-1"] .ct-header [data-id="logo"] .site-title {--fontWeight:700;--fontSize:25px;--lineHeight:1.5;--linkInitialColor:var(--paletteColor4);} [data-header*="type-1"] .ct-header [data-id="menu"] > ul > li > a {--fontWeight:700;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;--linkInitialColor:var(--color);} [data-header*="type-1"] .ct-header [data-id="menu"][data-menu*="type-3"] > ul > li > a {--linkHoverColor:#ffffff;--linkActiveColor:#ffffff;} [data-header*="type-1"] .ct-header [data-id="menu"] .sub-menu {--linkInitialColor:#ffffff;--fontWeight:500;--fontSize:12px;--dropdown-divider:1px dashed rgba(255, 255, 255, 0.1);--box-shadow:0px 10px 20px rgba(41, 51, 61, 0.1);--border-radius:0px 0px 2px 2px;} [data-header*="type-1"] .ct-header [data-row*="middle"] {--height:99px;background-color:rgba(255, 255, 255, 0);background-image:none;--borderTop:none;--borderBottom:none;--box-shadow:none;} [data-header*="type-1"] .ct-header [data-row*="middle"] > div {--borderTop:none;--borderBottom:none;} [data-header*="type-1"] [data-id="mobile-menu"] {--fontWeight:700;--fontSize:20px;--linkInitialColor:#ffffff;--mobile-menu-divider:none;} [data-header*="type-1"] #offcanvas .ct-panel-inner {background-color:rgba(18, 21, 25, 0.98);} [data-header*="type-1"] #offcanvas {--side-panel-width:500px;} [data-header*="type-1"] [data-behaviour*="side"] {--box-shadow:0px 0px 70px rgba(0, 0, 0, 0.35);} [data-header*="type-1"] #search-modal .ct-search-results a {--fontWeight:500;--fontSize:14px;--lineHeight:1.4;} [data-header*="type-1"] #search-modal {--linkInitialColor:#ffffff;--form-text-initial-color:#ffffff;--form-text-focus-color:#ffffff;background-color:rgba(18, 21, 25, 0.98);} [data-header*="type-1"] [data-id="trigger"] {--icon-size:19px;} [data-header*="type-1"] [data-id="trigger"] .ct-label {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;} [data-header*="type-1"] {--header-height:99px;} [data-footer*="type-1"] .ct-footer [data-row*="bottom"] > div {--container-spacing:25px;--border:none;--grid-template-columns:initial;} [data-footer*="type-1"] .ct-footer [data-row*="bottom"] .widget-title {--fontSize:16px;} [data-footer*="type-1"] .ct-footer [data-row*="bottom"] {background-color:transparent;} [data-footer*="type-1"] [data-id="copyright"] {--fontWeight:400;--fontSize:15px;--lineHeight:1.3;} [data-footer*="type-1"] [data-id="socials"].ct-footer-socials .ct-label {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;} [data-footer*="type-1"] [data-id="socials"].ct-footer-socials [data-color="custom"] {--background-color:rgba(218, 222, 228, 0.3);--background-hover-color:var(--paletteColor1);} [data-footer*="type-1"] .ct-footer [data-row*="top"] > div {--container-spacing:30px;--border:none;--grid-template-columns:repeat(2, 1fr);} [data-footer*="type-1"] .ct-footer [data-row*="top"] .widget-title {--fontSize:16px;} [data-footer*="type-1"] .ct-footer [data-row*="top"] {background-color:transparent;} [data-footer*="type-1"] footer.ct-footer {background-color:var(--paletteColor6);}:root {--fontFamily:Arial;--fontWeight:400;--textTransform:none;--textDecoration:none;--fontSize:22px;--lineHeight:1.65;--letterSpacing:0em;--buttonFontWeight:500;--buttonFontSize:15px;--has-classic-forms:var(--true);--has-modern-forms:var(--false);--form-field-border-initial-color:var(--border-color);--form-field-border-focus-color:var(--paletteColor1);--form-selection-control-initial-color:var(--border-color);--form-selection-control-accent-color:var(--paletteColor1);--paletteColor1:#3eaf7c;--paletteColor2:#33a370;--paletteColor3:rgba(44, 62, 80, 0.9);--paletteColor4:rgba(44, 62, 80, 1);--paletteColor5:#ffffff;--paletteColor6:#f2f5f7;--paletteColor7:#FAFBFC;--paletteColor8:#ffffff;--color:var(--paletteColor3);--linkInitialColor:var(--paletteColor1);--linkHoverColor:var(--paletteColor2);--selectionTextColor:#ffffff;--selectionBackgroundColor:var(--paletteColor1);--border-color:var(--paletteColor5);--headings-color:var(--paletteColor4);--content-spacing:1.5em;--buttonMinHeight:40px;--buttonTextInitialColor:#ffffff;--buttonTextHoverColor:#ffffff;--buttonInitialColor:var(--paletteColor1);--buttonHoverColor:var(--paletteColor2);--button-border:none;--buttonBorderRadius:3px;--button-padding:5px 20px;--normal-container-max-width:1290px;--content-vertical-spacing:60px;--narrow-container-max-width:750px;--wide-offset:130px;}h1 {--fontFamily:Arial;--fontWeight:700;--fontSize:40px;--lineHeight:1.5;}h2 {--fontFamily:Arial;--fontWeight:700;--fontSize:35px;--lineHeight:1.5;}h3 {--fontFamily:Arial;--fontWeight:700;--fontSize:30px;--lineHeight:1.5;}h4 {--fontFamily:Arial;--fontWeight:700;--fontSize:25px;--lineHeight:1.5;}h5 {--fontWeight:700;--fontSize:20px;--lineHeight:1.5;}h6 {--fontWeight:700;--fontSize:16px;--lineHeight:1.5;}.wp-block-quote.is-style-large p, .wp-block-pullquote p, .ct-quote-widget blockquote {--fontFamily:Arial;--fontWeight:600;--fontSize:25px;}code, kbd, samp, pre {--fontFamily:monospace;--fontWeight:400;--fontSize:16px;}.ct-sidebar .widget-title {--fontSize:18px;}.ct-breadcrumbs {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;}body {background-color:var(--paletteColor5);} [data-prefix="single_blog_post"] .entry-header .page-title {--fontSize:30px;} [data-prefix="single_blog_post"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="single_blog_post"] .hero-section[data-type="type-2"] {--alignment:center;--vertical-alignment:center;--min-height:50px;background-color:var(--paletteColor6);background-image:none;--container-padding:50px 0;} [data-prefix="single_blog_post"] .hero-section .entry-meta {--itemSpacing:33px;} [data-prefix="blog"] .entry-header .page-title {--fontSize:30px;} [data-prefix="blog"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="categories"] .entry-header .page-title {--fontSize:30px;} [data-prefix="categories"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="search"] .entry-header .page-title {--fontSize:30px;} [data-prefix="search"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="author"] .entry-header .page-title {--fontSize:30px;} [data-prefix="author"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="author"] .hero-section[data-type="type-2"] {background-color:var(--paletteColor6);background-image:none;--container-padding:50px 0;} [data-prefix="single_page"] .entry-header .page-title {--fontSize:30px;} [data-prefix="single_page"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="jetpack-portfolio_single"] .entry-header .page-title {--fontSize:30px;} [data-prefix="jetpack-portfolio_single"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="jetpack-portfolio_archive"] .entry-header .page-title {--fontSize:30px;} [data-prefix="jetpack-portfolio_archive"] .entry-header .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;--lineHeight:1.3;} [data-prefix="blog"] .entry-card .entry-title {--fontSize:20px;--lineHeight:1.3;} [data-prefix="blog"] .entry-card .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;} [data-prefix="blog"] [data-cards="simple"] .entry-card {--card-border:1px solid var(--paletteColor4);} [data-prefix="blog"] .entries {--grid-columns-gap:21px;} [data-prefix="blog"] .entry-card {--horizontal-alignment:center;} [data-prefix="categories"] .entries {--grid-template-columns:repeat(3, minmax(0, 1fr));} [data-prefix="categories"] .entry-card .entry-title {--fontSize:20px;--lineHeight:1.3;} [data-prefix="categories"] .entry-card .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;} [data-prefix="categories"] .entry-card {background-color:var(--paletteColor8);--box-shadow:0px 12px 18px -6px rgba(34, 56, 101, 0.04);} [data-prefix="author"] .entries {--grid-template-columns:repeat(3, minmax(0, 1fr));} [data-prefix="author"] .entry-card .entry-title {--fontSize:20px;--lineHeight:1.3;} [data-prefix="author"] .entry-card .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;} [data-prefix="author"] .entry-card {background-color:var(--paletteColor8);--box-shadow:0px 12px 18px -6px rgba(34, 56, 101, 0.04);} [data-prefix="search"] .entry-card .entry-title {--fontSize:20px;--lineHeight:1.3;} [data-prefix="search"] .entry-card .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;} [data-prefix="search"] .entry-card {background-color:var(--paletteColor8);--box-shadow:0px 12px 18px -6px rgba(34, 56, 101, 0.04);} [data-prefix="jetpack-portfolio_archive"] .entries {--grid-template-columns:repeat(3, minmax(0, 1fr));} [data-prefix="jetpack-portfolio_archive"] .entry-card .entry-title {--fontSize:20px;--lineHeight:1.3;} [data-prefix="jetpack-portfolio_archive"] .entry-card .entry-meta {--fontWeight:600;--textTransform:uppercase;--fontSize:12px;} [data-prefix="jetpack-portfolio_archive"] .entry-card {background-color:var(--paletteColor8);--box-shadow:0px 12px 18px -6px rgba(34, 56, 101, 0.04);}form textarea {--form-field-height:170px;} [data-sidebar] {--sidebar-width:23%;--sidebar-width-no-unit:23;--sidebar-offset:11px;}.ct-sidebar {--linkInitialColor:var(--color);--sidebar-widgets-spacing:15px;}.ct-back-to-top {--icon-color:#ffffff;--icon-hover-color:#ffffff;--border-radius:2px;} [data-prefix="single_blog_post"] .ct-share-box[data-location="bottom"] {--margin:47px;} [data-prefix="single_blog_post"] .ct-share-box[data-type="type-1"] {--border:1px solid var(--border-color);} [data-prefix="single_blog_post"] .author-box {--spacing:11px;} [data-prefix="single_blog_post"] .author-box[data-type="type-2"] {--border-color:var(--paletteColor4);} [data-prefix="single_blog_post"] .post-navigation {--linkInitialColor:var(--color);} [data-prefix="single_blog_post"] .ct-related-posts-container {background-color:var(--paletteColor6);} [data-prefix="single_blog_post"] .ct-related-posts {--grid-template-columns:repeat(4, 1fr);} [data-prefix="jetpack-portfolio_single"] [class*="ct-container"] > article[class*="post"] {--has-boxed:var(--false);--has-wide:var(--true);} [data-prefix="single_blog_post"] {background-color:#ffffff;} [data-prefix="single_blog_post"] [class*="ct-container"] > article[class*="post"] {--has-boxed:var(--false);--has-wide:var(--true);} [data-prefix="single_page"] [class*="ct-container"] > article[class*="post"] {--has-boxed:var(--false);--has-wide:var(--true);}@media (max-width: 999.98px) {[data-header*="type-1"] .ct-header [data-row*="middle"] {--height:70px;} [data-header*="type-1"] #offcanvas {--side-panel-width:65vw;} [data-header*="type-1"] {--header-height:70px;} [data-footer*="type-1"] .ct-footer [data-row*="bottom"] > div {--grid-template-columns:initial;} [data-footer*="type-1"] .ct-footer [data-row*="top"] > div {--grid-template-columns:initial;} [data-prefix="categories"] .entries {--grid-template-columns:repeat(2, minmax(0, 1fr));} [data-prefix="author"] .entries {--grid-template-columns:repeat(2, minmax(0, 1fr));} [data-prefix="jetpack-portfolio_archive"] .entries {--grid-template-columns:repeat(2, minmax(0, 1fr));} [data-prefix="single_blog_post"] .ct-related-posts {--grid-template-columns:repeat(2, 1fr);}}@media (max-width: 689.98px) {[data-header*="type-1"] #offcanvas {--side-panel-width:90vw;} [data-footer*="type-1"] .ct-footer [data-row*="bottom"] > div {--container-spacing:15px;--grid-template-columns:initial;} [data-footer*="type-1"] .ct-footer [data-row*="top"] > div {--grid-template-columns:initial;} [data-prefix="blog"] .entry-card .entry-title {--fontSize:18px;} [data-prefix="categories"] .entries {--grid-template-columns:repeat(1, minmax(0, 1fr));} [data-prefix="categories"] .entry-card .entry-title {--fontSize:18px;} [data-prefix="author"] .entries {--grid-template-columns:repeat(1, minmax(0, 1fr));} [data-prefix="author"] .entry-card .entry-title {--fontSize:18px;} [data-prefix="search"] .entry-card .entry-title {--fontSize:18px;} [data-prefix="jetpack-portfolio_archive"] .entries {--grid-template-columns:repeat(1, minmax(0, 1fr));} [data-prefix="jetpack-portfolio_archive"] .entry-card .entry-title {--fontSize:18px;}:root {--content-vertical-spacing:50px;} [data-prefix="single_blog_post"] .ct-related-posts {--grid-template-columns:repeat(1, 1fr);}}</style>

<!-- Google AdSense snippet added by Site Kit -->
<meta name="google-adsense-platform-account" content="ca-host-pub-2644536267352236">
<meta name="google-adsense-platform-domain" content="sitekit.withgoogle.com">
<!-- End Google AdSense snippet added by Site Kit -->
			<style type="text/css">
				/* If html does not have either class, do not show lazy loaded images. */
				html:not( .jetpack-lazy-images-js-enabled ):not( .js ) .jetpack-lazy-image {
					display: none;
				}
			</style>
			<script>
				document.documentElement.classList.add(
					'jetpack-lazy-images-js-enabled'
				);
			</script>
		<link rel="icon" href="https://i0.wp.com/thecleverprogrammer.com/wp-content/uploads/2021/04/cropped-thecleverprogrammer.png?fit=32%2C32&#038;ssl=1" sizes="32x32" />
<link rel="icon" href="https://i0.wp.com/thecleverprogrammer.com/wp-content/uploads/2021/04/cropped-thecleverprogrammer.png?fit=192%2C192&#038;ssl=1" sizes="192x192" />
<link rel="apple-touch-icon" href="https://i0.wp.com/thecleverprogrammer.com/wp-content/uploads/2021/04/cropped-thecleverprogrammer.png?fit=180%2C180&#038;ssl=1" />
<meta name="msapplication-TileImage" content="https://i0.wp.com/thecleverprogrammer.com/wp-content/uploads/2021/04/cropped-thecleverprogrammer.png?fit=270%2C270&#038;ssl=1" />
		<!-- Jetpack Google Analytics -->
		<script async src='https://www.googletagmanager.com/gtag/js?id=G-W5B0M2RLRX'></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag() { dataLayer.push( arguments ); }
			gtag( 'js', new Date() );
			gtag( 'config', "G-W5B0M2RLRX" );
			gtag( "event", "exception", {"description":"404","fatal":false} );
		</script>
		<!-- End Jetpack Google Analytics -->
			</head>

<body class="error404 wp-custom-logo wp-embed-responsive qubely qubely-frontend ct-loading" data-link="type-2" data-prefix="" data-header="type-1" data-footer="type-1" >

<a class="skip-link show-on-focus" href="#main">
	Skip to content</a>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0.49803921568627" /><feFuncG type="table" tableValues="0 0.49803921568627" /><feFuncB type="table" tableValues="0 0.49803921568627" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 0.27843137254902" /><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0" /><feFuncG type="table" tableValues="0 0.64705882352941" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.78039215686275 1" /><feFuncG type="table" tableValues="0 0.94901960784314" /><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.44705882352941 0.4" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.098039215686275 1" /><feFuncG type="table" tableValues="0 0.66274509803922" /><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><div class="ct-drawer-canvas">
		<div id="search-modal" class="ct-panel" data-behaviour="modal">
			<div class="ct-panel-actions">
				<button class="ct-toggle-close" data-type="type-1" aria-label="Close search modal">
					<svg class="ct-icon" width="12" height="12" viewBox="0 0 15 15"><path d="M1 15a1 1 0 01-.71-.29 1 1 0 010-1.41l5.8-5.8-5.8-5.8A1 1 0 011.7.29l5.8 5.8 5.8-5.8a1 1 0 011.41 1.41l-5.8 5.8 5.8 5.8a1 1 0 01-1.41 1.41l-5.8-5.8-5.8 5.8A1 1 0 011 15z"/></svg>				</button>
			</div>

			<div class="ct-panel-content">
				

<form
	role="search" method="get"
	class="search-form"
	action="https://thecleverprogrammer.com"
	aria-haspopup="listbox"
	data-live-results="thumbs">

	<input type="search" class="modal-field" placeholder="Search" value="" name="s" autocomplete="off" title="Search Input" />

	<button type="submit" class="search-submit" aria-label="Search button">
		<svg class="ct-icon" aria-hidden="true" width="15" height="15" viewBox="0 0 15 15"><path d="M14.8,13.7L12,11c0.9-1.2,1.5-2.6,1.5-4.2c0-3.7-3-6.8-6.8-6.8S0,3,0,6.8s3,6.8,6.8,6.8c1.6,0,3.1-0.6,4.2-1.5l2.8,2.8c0.1,0.1,0.3,0.2,0.5,0.2s0.4-0.1,0.5-0.2C15.1,14.5,15.1,14,14.8,13.7z M1.5,6.8c0-2.9,2.4-5.2,5.2-5.2S12,3.9,12,6.8S9.6,12,6.8,12S1.5,9.6,1.5,6.8z"/></svg>
		<span data-loader="circles"><span></span><span></span><span></span></span>
	</button>

	
			<input type="hidden" name="ct_post_type" value="post:page:jetpack-portfolio">
	
	
			<div class="screen-reader-text" aria-live="polite" role="status">
			No results		</div>
	
</form>


			</div>
		</div>

		<div id="offcanvas" class="ct-panel ct-header" data-behaviour="right-side" ><div class="ct-panel-inner">
		<div class="ct-panel-actions">
			<button class="ct-toggle-close" data-type="type-1" aria-label="Close drawer">
				<svg class="ct-icon" width="12" height="12" viewBox="0 0 15 15"><path d="M1 15a1 1 0 01-.71-.29 1 1 0 010-1.41l5.8-5.8-5.8-5.8A1 1 0 011.7.29l5.8 5.8 5.8-5.8a1 1 0 011.41 1.41l-5.8 5.8 5.8 5.8a1 1 0 01-1.41 1.41l-5.8-5.8-5.8 5.8A1 1 0 011 15z"/></svg>
			</button>
		</div>
		<div class="ct-panel-content" data-device="desktop" ></div><div class="ct-panel-content" data-device="mobile" >
<nav 
	class="mobile-menu" 
	data-id="mobile-menu" data-interaction="click" data-toggle-type="type-1" 	aria-label="Off Canvas Menu">
	<ul id="menu-primary-1" class=""><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-8468"><a href="https://thecleverprogrammer.com/" class="ct-menu-link">Thecleverprogrammer</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-5638"><a href="https://thecleverprogrammer.com/machine-learning/" class="ct-menu-link">All Articles</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="https://thecleverprogrammer.com/about/" class="ct-menu-link">About</a></li>
</ul></nav>

</div></div></div>
	<a href="#main-container" class="ct-back-to-top ct-hidden-sm"
		data-shape="square"
		data-alignment="right"
		title="Go to top" aria-label="Go to top">

		<svg class="ct-icon" width="15" height="15" viewBox="0 0 20 20"><path d="M10,0L9.4,0.6L0.8,9.1l1.2,1.2l7.1-7.1V20h1.7V3.3l7.1,7.1l1.2-1.2l-8.5-8.5L10,0z"/></svg>	</a>

	</div>
<div id="main-container">
	<header id="header" class="ct-header" data-id="type-1" itemscope="" itemtype="https://schema.org/WPHeader" ><div data-device="desktop" ><div data-row="middle" data-column-set="2" ><div class="ct-container" ><div data-column="start" data-placements="1" ><div data-items="primary" >
<div	class="site-branding"
	data-id="logo" 		itemscope="itemscope" itemtype="https://schema.org/Organization" >

	
	</div>

</div></div><div data-column="end" data-placements="1" ><div data-items="primary" >
<nav
	id="header-menu-1"
	class="header-menu-1"
	data-id="menu" data-interaction="hover" 	data-menu="type-1"
	data-dropdown="type-1:simple"		data-responsive="no"	itemscope="" itemtype="https://schema.org/SiteNavigationElement" 	aria-label="Header Menu">

	<ul id="menu-primary" class="menu"><li id="menu-item-8468" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-8468"><a href="https://thecleverprogrammer.com/" class="ct-menu-link">Thecleverprogrammer</a></li>
<li id="menu-item-5638" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-5638"><a href="https://thecleverprogrammer.com/machine-learning/" class="ct-menu-link">All Articles</a></li>
<li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="https://thecleverprogrammer.com/about/" class="ct-menu-link">About</a></li>
</ul></nav>


<button
	data-toggle-panel="#search-modal"
	class="ct-header-search ct-toggle "
	aria-label="Open search form"
	data-label="left"
	data-id="search" >

	<span class="ct-label ct-hidden-sm ct-hidden-md ct-hidden-lg">Search</span>

	<svg class="ct-icon" aria-hidden="true" width="15" height="15" viewBox="0 0 15 15"><path d="M14.8,13.7L12,11c0.9-1.2,1.5-2.6,1.5-4.2c0-3.7-3-6.8-6.8-6.8S0,3,0,6.8s3,6.8,6.8,6.8c1.6,0,3.1-0.6,4.2-1.5l2.8,2.8c0.1,0.1,0.3,0.2,0.5,0.2s0.4-0.1,0.5-0.2C15.1,14.5,15.1,14,14.8,13.7z M1.5,6.8c0-2.9,2.4-5.2,5.2-5.2S12,3.9,12,6.8S9.6,12,6.8,12S1.5,9.6,1.5,6.8z"/></svg></button>
</div></div></div></div></div><div data-device="mobile" ><div data-row="middle" data-column-set="2" ><div class="ct-container" ><div data-column="start" data-placements="1" ><div data-items="primary" >
<div	class="site-branding"
	data-id="logo" 		itemscope="itemscope" itemtype="https://schema.org/Organization" >

	
	</div>

</div></div><div data-column="end" data-placements="1" ><div data-items="primary" >
<button
	data-toggle-panel="#offcanvas"
	class="ct-header-trigger ct-toggle "
	data-design="simple"
	data-label="right"
	aria-label="Open off canvas"
	data-id="trigger" >

	<span class="ct-label "></span>

	<svg
		class="ct-icon"
		width="18" height="14" viewBox="0 0 18 14"
		aria-hidden="true"
		data-type="type-1">

		<rect y="0.00" width="18" height="1.7" rx="1"/>
		<rect y="6.15" width="18" height="1.7" rx="1"/>
		<rect y="12.3" width="18" height="1.7" rx="1"/>
	</svg>
</button>
</div></div></div></div></div></header>
	<main id="main" class="site-main hfeed" >

		<div class="ct-container" data-vertical-spacing="top:bottom">
	<section class="ct-no-results">

		<section class="hero-section" data-type="type-1">
			<header class="entry-header">
				<h1 class="page-title" itemprop="headline">
					Oops! That page can&rsquo;t be found.	
				</h1>

				<div class="page-description">
					It looks like nothing was found at this location. Maybe try to search for something else?				</div>
			</header>
		</section>

		<div class="entry-content">
			

<form
	role="search" method="get"
	class="search-form"
	action="https://thecleverprogrammer.com"
	aria-haspopup="listbox"
	data-live-results="thumbs">

	<input type="search"  placeholder="Search" value="" name="s" autocomplete="off" title="Search Input" />

	<button type="submit" class="search-submit" aria-label="Search button">
		<svg class="ct-icon" aria-hidden="true" width="15" height="15" viewBox="0 0 15 15"><path d="M14.8,13.7L12,11c0.9-1.2,1.5-2.6,1.5-4.2c0-3.7-3-6.8-6.8-6.8S0,3,0,6.8s3,6.8,6.8,6.8c1.6,0,3.1-0.6,4.2-1.5l2.8,2.8c0.1,0.1,0.3,0.2,0.5,0.2s0.4-0.1,0.5-0.2C15.1,14.5,15.1,14,14.8,13.7z M1.5,6.8c0-2.9,2.4-5.2,5.2-5.2S12,3.9,12,6.8S9.6,12,6.8,12S1.5,9.6,1.5,6.8z"/></svg>
		<span data-loader="circles"><span></span><span></span><span></span></span>
	</button>

	
	
	
			<div class="screen-reader-text" aria-live="polite" role="status">
			No results		</div>
	
</form>


		</div>

	</section>
</div>	</main>

	<footer class="ct-footer" data-id="type-1" itemscope="" itemtype="https://schema.org/WPFooter" ><div data-row="top" ><div class="ct-container" ><div data-column="socials" >
<div
	class="ct-footer-socials"
	data-id="socials" >

	
		<div class="ct-social-box" data-icon-size="custom" data-color="custom" data-icons-type="simple" >
			
			
							
				<a href="https://www.facebook.com/thecleverprogrammer" data-network="facebook" aria-label="Facebook" rel="noopener" >
					<span class="ct-icon-container" >
				<svg
				width="20px"
				height="20px"
				viewBox="0 0 20 20"
				aria-hidden="true">
					<path d="M20,10.1c0-5.5-4.5-10-10-10S0,4.5,0,10.1c0,5,3.7,9.1,8.4,9.9v-7H5.9v-2.9h2.5V7.9C8.4,5.4,9.9,4,12.2,4c1.1,0,2.2,0.2,2.2,0.2v2.5h-1.3c-1.2,0-1.6,0.8-1.6,1.6v1.9h2.8L13.9,13h-2.3v7C16.3,19.2,20,15.1,20,10.1z"/>
				</svg>
			</span><span class="ct-label" >Facebook</span>				</a>
							
				<a href="https://www.instagram.com/the.clever.programmer/" data-network="instagram" aria-label="Instagram" rel="noopener" >
					<span class="ct-icon-container" >
				<svg
				width="20"
				height="20"
				viewBox="0 0 20 20"
				aria-hidden="true">
					<circle cx="10" cy="10" r="3.3"/>
					<path d="M14.2,0H5.8C2.6,0,0,2.6,0,5.8v8.3C0,17.4,2.6,20,5.8,20h8.3c3.2,0,5.8-2.6,5.8-5.8V5.8C20,2.6,17.4,0,14.2,0zM10,15c-2.8,0-5-2.2-5-5s2.2-5,5-5s5,2.2,5,5S12.8,15,10,15z M15.8,5C15.4,5,15,4.6,15,4.2s0.4-0.8,0.8-0.8s0.8,0.4,0.8,0.8S16.3,5,15.8,5z"/>
				</svg>
			</span><span class="ct-label" >Instagram</span>				</a>
							
				<a href="https://medium.com/@amankharwal" data-network="medium" aria-label="Medium" rel="noopener" >
					<span class="ct-icon-container" >
				<svg
				width="20"
				height="20"
				viewBox="0 0 20 20"
				aria-hidden="true">
					<path d="M2.4,5.3c0-0.2-0.1-0.5-0.3-0.7L0.3,2.4V2.1H6l4.5,9.8l3.9-9.8H20v0.3l-1.6,1.5c-0.1,0.1-0.2,0.3-0.2,0.4v11.2c0,0.2,0,0.3,0.2,0.4l1.6,1.5v0.3h-7.8v-0.3l1.6-1.6c0.2-0.2,0.2-0.2,0.2-0.4V6.5L9.4,17.9H8.8L3.6,6.5v7.6c0,0.3,0.1,0.6,0.3,0.9L6,17.6v0.3H0v-0.3L2.1,15c0.2-0.2,0.3-0.6,0.3-0.9V5.3z"/>
				</svg>
			</span><span class="ct-label" >Medium</span>				</a>
							
				<a href="https://www.linkedin.com/company/thecleverprogrammer/" data-network="linkedin" aria-label="LinkedIn" rel="noopener" >
					<span class="ct-icon-container" >
				<svg
				width="20px"
				height="20px"
				viewBox="0 0 20 20"
				aria-hidden="true">
					<path d="M18.6,0H1.4C0.6,0,0,0.6,0,1.4v17.1C0,19.4,0.6,20,1.4,20h17.1c0.8,0,1.4-0.6,1.4-1.4V1.4C20,0.6,19.4,0,18.6,0z M6,17.1h-3V7.6h3L6,17.1L6,17.1zM4.6,6.3c-1,0-1.7-0.8-1.7-1.7s0.8-1.7,1.7-1.7c0.9,0,1.7,0.8,1.7,1.7C6.3,5.5,5.5,6.3,4.6,6.3z M17.2,17.1h-3v-4.6c0-1.1,0-2.5-1.5-2.5c-1.5,0-1.8,1.2-1.8,2.5v4.7h-3V7.6h2.8v1.3h0c0.4-0.8,1.4-1.5,2.8-1.5c3,0,3.6,2,3.6,4.5V17.1z"/>
				</svg>
			</span><span class="ct-label" >LinkedIn</span>				</a>
			
			
					</div>

	</div>

</div><div data-column="ghost"></div></div></div><div data-row="bottom" ><div class="ct-container" data-columns-divider="md:sm" ><div data-column="copyright" >
<div
	class="ct-footer-copyright"
	data-id="copyright" >

	<p>Copyright © Thecleverprogrammer.com 2022 </p></div>
</div></div></div></footer></div>

<!-- wpcom_wp_footer -->
<script defer id="bilmur" data-provider="wordpress.com" data-service="atomic"  src="https://s0.wp.com/wp-content/js/bilmur.min.js?m=202234"></script>
		<div id="jp-carousel-loading-overlay">
			<div id="jp-carousel-loading-wrapper">
				<span id="jp-carousel-library-loading">&nbsp;</span>
			</div>
		</div>
		<div class="jp-carousel-overlay" style="display: none;">

		<div class="jp-carousel-container">
			<!-- The Carousel Swiper -->
			<div
				class="jp-carousel-wrap swiper-container jp-carousel-swiper-container jp-carousel-transitions"
				itemscope
				itemtype="https://schema.org/ImageGallery">
				<div class="jp-carousel swiper-wrapper"></div>
				<div class="jp-swiper-button-prev swiper-button-prev">
					<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
						<mask id="maskPrev" mask-type="alpha" maskUnits="userSpaceOnUse" x="8" y="6" width="9" height="12">
							<path d="M16.2072 16.59L11.6496 12L16.2072 7.41L14.8041 6L8.8335 12L14.8041 18L16.2072 16.59Z" fill="white"/>
						</mask>
						<g mask="url(#maskPrev)">
							<rect x="0.579102" width="23.8823" height="24" fill="#FFFFFF"/>
						</g>
					</svg>
				</div>
				<div class="jp-swiper-button-next swiper-button-next">
					<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
						<mask id="maskNext" mask-type="alpha" maskUnits="userSpaceOnUse" x="8" y="6" width="8" height="12">
							<path d="M8.59814 16.59L13.1557 12L8.59814 7.41L10.0012 6L15.9718 12L10.0012 18L8.59814 16.59Z" fill="white"/>
						</mask>
						<g mask="url(#maskNext)">
							<rect x="0.34375" width="23.8822" height="24" fill="#FFFFFF"/>
						</g>
					</svg>
				</div>
			</div>
			<!-- The main close buton -->
			<div class="jp-carousel-close-hint">
				<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<mask id="maskClose" mask-type="alpha" maskUnits="userSpaceOnUse" x="5" y="5" width="15" height="14">
						<path d="M19.3166 6.41L17.9135 5L12.3509 10.59L6.78834 5L5.38525 6.41L10.9478 12L5.38525 17.59L6.78834 19L12.3509 13.41L17.9135 19L19.3166 17.59L13.754 12L19.3166 6.41Z" fill="white"/>
					</mask>
					<g mask="url(#maskClose)">
						<rect x="0.409668" width="23.8823" height="24" fill="#FFFFFF"/>
					</g>
				</svg>
			</div>
			<!-- Image info, comments and meta -->
			<div class="jp-carousel-info">
				<div class="jp-carousel-info-footer">
					<div class="jp-carousel-pagination-container">
						<div class="jp-swiper-pagination swiper-pagination"></div>
						<div class="jp-carousel-pagination"></div>
					</div>
					<div class="jp-carousel-photo-title-container">
						<h2 class="jp-carousel-photo-caption"></h2>
					</div>
					<div class="jp-carousel-photo-icons-container">
						<a href="#" class="jp-carousel-icon-btn jp-carousel-icon-info" aria-label="Toggle photo metadata visibility">
							<span class="jp-carousel-icon">
								<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<mask id="maskInfo" mask-type="alpha" maskUnits="userSpaceOnUse" x="2" y="2" width="21" height="20">
										<path fill-rule="evenodd" clip-rule="evenodd" d="M12.7537 2C7.26076 2 2.80273 6.48 2.80273 12C2.80273 17.52 7.26076 22 12.7537 22C18.2466 22 22.7046 17.52 22.7046 12C22.7046 6.48 18.2466 2 12.7537 2ZM11.7586 7V9H13.7488V7H11.7586ZM11.7586 11V17H13.7488V11H11.7586ZM4.79292 12C4.79292 16.41 8.36531 20 12.7537 20C17.142 20 20.7144 16.41 20.7144 12C20.7144 7.59 17.142 4 12.7537 4C8.36531 4 4.79292 7.59 4.79292 12Z" fill="white"/>
									</mask>
									<g mask="url(#maskInfo)">
										<rect x="0.8125" width="23.8823" height="24" fill="#FFFFFF"/>
									</g>
								</svg>
							</span>
						</a>
												<a href="#" class="jp-carousel-icon-btn jp-carousel-icon-comments" aria-label="Toggle photo comments visibility">
							<span class="jp-carousel-icon">
								<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<mask id="maskComments" mask-type="alpha" maskUnits="userSpaceOnUse" x="2" y="2" width="21" height="20">
										<path fill-rule="evenodd" clip-rule="evenodd" d="M4.3271 2H20.2486C21.3432 2 22.2388 2.9 22.2388 4V16C22.2388 17.1 21.3432 18 20.2486 18H6.31729L2.33691 22V4C2.33691 2.9 3.2325 2 4.3271 2ZM6.31729 16H20.2486V4H4.3271V18L6.31729 16Z" fill="white"/>
									</mask>
									<g mask="url(#maskComments)">
										<rect x="0.34668" width="23.8823" height="24" fill="#FFFFFF"/>
									</g>
								</svg>

								<span class="jp-carousel-has-comments-indicator" aria-label="This image has comments."></span>
							</span>
						</a>
											</div>
				</div>
				<div class="jp-carousel-info-extra">
					<div class="jp-carousel-info-content-wrapper">
						<div class="jp-carousel-photo-title-container">
							<h2 class="jp-carousel-photo-title"></h2>
						</div>
						<div class="jp-carousel-comments-wrapper">
															<div id="jp-carousel-comments-loading">
									<span>Loading Comments...</span>
								</div>
								<div class="jp-carousel-comments"></div>
								<div id="jp-carousel-comment-form-container">
									<span id="jp-carousel-comment-form-spinner">&nbsp;</span>
									<div id="jp-carousel-comment-post-results"></div>
																														<form id="jp-carousel-comment-form">
												<label for="jp-carousel-comment-form-comment-field" class="screen-reader-text">Write a Comment...</label>
												<textarea
													name="comment"
													class="jp-carousel-comment-form-field jp-carousel-comment-form-textarea"
													id="jp-carousel-comment-form-comment-field"
													placeholder="Write a Comment..."
												></textarea>
												<div id="jp-carousel-comment-form-submit-and-info-wrapper">
													<div id="jp-carousel-comment-form-commenting-as">
																													<fieldset>
																<label for="jp-carousel-comment-form-email-field">Email (Required)</label>
																<input type="text" name="email" class="jp-carousel-comment-form-field jp-carousel-comment-form-text-field" id="jp-carousel-comment-form-email-field" />
															</fieldset>
															<fieldset>
																<label for="jp-carousel-comment-form-author-field">Name (Required)</label>
																<input type="text" name="author" class="jp-carousel-comment-form-field jp-carousel-comment-form-text-field" id="jp-carousel-comment-form-author-field" />
															</fieldset>
															<fieldset>
																<label for="jp-carousel-comment-form-url-field">Website</label>
																<input type="text" name="url" class="jp-carousel-comment-form-field jp-carousel-comment-form-text-field" id="jp-carousel-comment-form-url-field" />
															</fieldset>
																											</div>
													<input
														type="submit"
														name="submit"
														class="jp-carousel-comment-form-button"
														id="jp-carousel-comment-form-button-submit"
														value="Post Comment" />
												</div>
											</form>
																											</div>
													</div>
						<div class="jp-carousel-image-meta">
							<div class="jp-carousel-title-and-caption">
								<div class="jp-carousel-photo-info">
									<h3 class="jp-carousel-caption" itemprop="caption description"></h3>
								</div>

								<div class="jp-carousel-photo-description"></div>
							</div>
							<ul class="jp-carousel-image-exif" style="display: none;"></ul>
							<a class="jp-carousel-image-download" target="_blank" style="display: none;">
								<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
									<mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="3" y="3" width="19" height="18">
										<path fill-rule="evenodd" clip-rule="evenodd" d="M5.84615 5V19H19.7775V12H21.7677V19C21.7677 20.1 20.8721 21 19.7775 21H5.84615C4.74159 21 3.85596 20.1 3.85596 19V5C3.85596 3.9 4.74159 3 5.84615 3H12.8118V5H5.84615ZM14.802 5V3H21.7677V10H19.7775V6.41L9.99569 16.24L8.59261 14.83L18.3744 5H14.802Z" fill="white"/>
									</mask>
									<g mask="url(#mask0)">
										<rect x="0.870605" width="23.8823" height="24" fill="#FFFFFF"/>
									</g>
								</svg>
								<span class="jp-carousel-download-text"></span>
							</a>
							<div class="jp-carousel-image-map" style="display: none;"></div>
						</div>
					</div>
				</div>
			</div>
		</div>

		</div>
		<script id='jetpack-carousel-js-extra'>
var jetpackSwiperLibraryPath = {"url":"https:\/\/thecleverprogrammer.com\/wp-content\/plugins\/jetpack\/_inc\/build\/carousel\/swiper-bundle.min.js"};
var jetpackCarouselStrings = {"widths":[370,700,1000,1200,1400,2000],"is_logged_in":"","lang":"en","ajaxurl":"https:\/\/thecleverprogrammer.com\/wp-admin\/admin-ajax.php","nonce":"cb1deda547","display_exif":"1","display_comments":"1","single_image_gallery":"1","single_image_gallery_media_file":"","background_color":"black","comment":"Comment","post_comment":"Post Comment","write_comment":"Write a Comment...","loading_comments":"Loading Comments...","download_original":"View full size <span class=\"photo-size\">{0}<span class=\"photo-size-times\">\u00d7<\/span>{1}<\/span>","no_comment_text":"Please be sure to submit some text with your comment.","no_comment_email":"Please provide an email address to comment.","no_comment_author":"Please provide your name to comment.","comment_post_error":"Sorry, but there was an error posting your comment. Please try again later.","comment_approved":"Your comment was approved.","comment_unapproved":"Your comment is in moderation.","camera":"Camera","aperture":"Aperture","shutter_speed":"Shutter Speed","focal_length":"Focal Length","copyright":"Copyright","comment_registration":"0","require_name_email":"1","login_url":"https:\/\/thecleverprogrammer.com\/wp-login.php","blog_id":"1","meta_data":["camera","aperture","shutter_speed","focal_length","copyright"]};
</script>
<script id='jetpack-lazy-images-js-extra'>
var jetpackLazyImagesL10n = {"loading_warning":"Images are still loading. Please cancel your print and try again."};
</script>
<script id='ct-scripts-js-extra'>
var ct_localizations = {"ajax_url":"https:\/\/thecleverprogrammer.com\/wp-admin\/admin-ajax.php","nonce":"8616850991","public_url":"https:\/\/thecleverprogrammer.com\/wp-content\/themes\/blocksy\/static\/bundle\/","rest_url":"https:\/\/thecleverprogrammer.com\/wp-json\/","search_url":"https:\/\/thecleverprogrammer.com\/search\/QUERY_STRING\/","show_more_text":"Show more","more_text":"More","search_live_results":"Search results","search_live_no_result":"No results","search_live_one_result":"You got %s result. Please press Tab to select it.","search_live_many_results":"You got %s results. Please press Tab to select one.","expand_submenu":"Expand dropdown menu","collapse_submenu":"Collapse dropdown menu","dynamic_js_chunks":[],"dynamic_styles":{"lazy_load":"https:\/\/thecleverprogrammer.com\/wp-content\/themes\/blocksy\/static\/bundle\/non-critical-styles.min.css","search_lazy":"https:\/\/thecleverprogrammer.com\/wp-content\/themes\/blocksy\/static\/bundle\/non-critical-search-styles.min.css"},"dynamic_styles_selectors":[]};
</script>
<script type='text/javascript'  src='https://thecleverprogrammer.com/_static/??-eJytUUFOAzEM/BCpaQ8FDoinVE7War1N4hA7rbavZ9luAVGKOHCyNPbMeOxjcUGyUTYosW05K/RkBcMeNpwD+Maxg7ITkzyXReK86PXueE0N4qOEvULHatB/Ag4zJzSWW8zX5ikOgKpkemamJNlpqFzsF8srIo/9imHyuk37IWTAKk0pXnruAvxBZq6bA+VOKmAzGeMahw+xiKfBjTfY0nydaU+laVEnXqkeqP6/zRfgm7jtKI1T5wcNoIbvQr7lLhIknDK/pOfler1cPdw/rR7fAHoY1LU='></script>
<script src='https://stats.wp.com/e-202234.js' defer></script>
<script>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:11.3-a.9',blog:'175928511',post:'0',tz:'5.5',srv:'thecleverprogrammer.com',hp:'atomic',ac:'2',amp:'0'} ]);
	_stq.push([ 'clickTrackerInit', '175928511', '0' ]);
</script>

</body>
</html>